#!/bin/bash

bochs -f scripts/bochsrc.txt
